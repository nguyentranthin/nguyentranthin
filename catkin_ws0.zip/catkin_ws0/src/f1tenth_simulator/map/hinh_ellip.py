import cv2
import numpy as np

# --- Tạo và lưu ảnh đường đua (Ellipse Track) ---
# Kích thước ảnh đường đua
track_width, track_height = 250, 200

# Tạo ảnh nền đen
track_image = np.zeros((track_height, track_width), dtype=np.uint8)

# Xác định tọa độ tâm của hình elip
center_x, center_y = track_width // 2, track_height // 2

# Bán kính theo chiều ngang và chiều dọc
radius_x = 75  # Bán kính theo chiều ngang
radius_y = 50  # Bán kính theo chiều dọc

# Vẽ hình elip với đường viền dày 15 pixels
cv2.ellipse(
    track_image,
    (center_x, center_y),  # Tâm của elip
    (radius_x, radius_y),  # Bán kính (ngang, dọc)
    0,                     # Góc quay của elip (0 độ)
    0, 360,                # Vẽ toàn bộ hình elip (0 đến 360 độ)
    255,                   # Màu trắng
    15                     # Độ dày của viền
)

# In ra kích thước chiều dài và chiều rộng của hình elip
width_ellipse = 2 * radius_x
height_ellipse = 2 * radius_y
print(f"Chiều dài hình elip: {width_ellipse} pixels")
print(f"Chiều rộng hình elip: {height_ellipse} pixels")

# Lưu ảnh đường đua vào file
cv2.imwrite("race_track_ellipse.png", track_image)

# Hiển thị hình ảnh đường đua
cv2.imshow("Race Track (Ellipse)", track_image)
cv2.waitKey(0)  # Chờ phím bấm bất kỳ để đóng cửa sổ
cv2.destroyAllWindows()
