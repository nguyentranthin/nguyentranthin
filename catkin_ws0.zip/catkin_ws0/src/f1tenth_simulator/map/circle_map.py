import cv2
import numpy as np

# --- Tạo và lưu ảnh đường đua (Circle Track) ---
# Kích thước ảnh đường đua
track_width, track_height = 250, 200

# Tạo ảnh nền đen
track_image = np.zeros((track_height, track_width), dtype=np.uint8)

# Tọa độ tâm và bán kính của đường tròn
center_x, center_y = track_width // 2, track_height // 2
radius = 50  # Bán kính đường tròn

# Vẽ đường tròn trên ảnh
cv2.circle(track_image, (center_x, center_y), radius, 255, 20)  # Đường tròn trắng dày 40 pixel

# Lưu ảnh đường đua vào file
cv2.imwrite("race_track.png", track_image)

# Hiển thị hình ảnh đường đua
cv2.imshow("Race Track", track_image)
cv2.waitKey(0)  # Chờ phím bấm bất kỳ để đóng cửa sổ
cv2.destroyAllWindows()