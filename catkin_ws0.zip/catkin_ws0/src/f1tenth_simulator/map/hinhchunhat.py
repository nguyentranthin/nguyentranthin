import cv2
import numpy as np

# --- Tạo và lưu ảnh đường đua (Rectangle Track) ---
# Kích thước ảnh đường đua
track_width, track_height = 250, 200

# Tạo ảnh nền đen
track_image = np.zeros((track_height, track_width), dtype=np.uint8)

# Xác định tọa độ tâm của hình chữ nhật
center_x, center_y = track_width // 2, track_height // 2

# Bán kính theo chiều ngang và chiều dọc
radius_x = 75  # Khoảng cách từ tâm đến cạnh theo chiều ngang
radius_y = 50  # Khoảng cách từ tâm đến cạnh theo chiều dọc

# Tọa độ các góc của hình chữ nhật
top_left = (center_x - radius_x, center_y - radius_y)       # Góc trên bên trái
bottom_right = (center_x + radius_x, center_y + radius_y)   # Góc dưới bên phải

# Vẽ hình chữ nhật với đường viền dày 2 pixels
cv2.rectangle(track_image, top_left, bottom_right, 255, 15)  # Màu trắng, độ dày 2 pixels
# In ra kích thước chiều dài và chiều rộng của hình chữ nhật
width_rectangle = 2 * radius_x
height_rectangle = 2 * radius_y
print(f"Chiều dài hình chữ nhật: {width_rectangle} pixels")
print(f"Chiều rộng hình chữ nhật: {height_rectangle} pixels")

# Lưu ảnh đường đua vào file
cv2.imwrite("race_track_rectangle.png", track_image)

# Hiển thị hình ảnh đường đua
cv2.imshow("Race Track (Rectangle)", track_image)
cv2.waitKey(0)  # Chờ phím bấm bất kỳ để đóng cửa sổ
cv2.destroyAllWindows()
